$(document).on('ready', init);

function init() {
    
    $('#brandy').on('click', openModal);
}

function openModal(){
}